"""Distributable add-on version shared by the local APIs."""
VERSION = '0.3.4~dev2'
